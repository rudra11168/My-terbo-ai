/**
 * Turbo AI design tokens.
 * Palette: deep indigo -> electric cyan, matching the app icon's spark motif.
 */

const colors = {
  light: {
    text: '#101124',
    tint: '#5B4FE9',

    background: '#F6F5FF',
    foreground: '#101124',

    card: '#FFFFFF',
    cardForeground: '#101124',

    primary: '#5B4FE9',
    primaryForeground: '#FFFFFF',

    secondary: '#EDEBFF',
    secondaryForeground: '#302B63',

    muted: '#EEEEF7',
    mutedForeground: '#6B6C85',

    accent: '#22D3EE',
    accentForeground: '#052B33',

    destructive: '#EF4444',
    destructiveForeground: '#FFFFFF',

    border: '#E3E1F5',
    input: '#E3E1F5',

    bubbleUser: '#5B4FE9',
    bubbleUserText: '#FFFFFF',
    bubbleAssistant: '#FFFFFF',
    bubbleAssistantText: '#101124',
  },

  dark: {
    text: '#EDEDF7',
    tint: '#8B7FFF',

    background: '#0A0B16',
    foreground: '#EDEDF7',

    card: '#14152A',
    cardForeground: '#EDEDF7',

    primary: '#8B7FFF',
    primaryForeground: '#0A0B16',

    secondary: '#1D1F3B',
    secondaryForeground: '#C9C8FF',

    muted: '#181A33',
    mutedForeground: '#9192B5',

    accent: '#22D3EE',
    accentForeground: '#052B33',

    destructive: '#F87171',
    destructiveForeground: '#1A0000',

    border: '#242648',
    input: '#242648',

    bubbleUser: '#5B4FE9',
    bubbleUserText: '#FFFFFF',
    bubbleAssistant: '#14152A',
    bubbleAssistantText: '#EDEDF7',
  },

  radius: 20,
};

export default colors;
