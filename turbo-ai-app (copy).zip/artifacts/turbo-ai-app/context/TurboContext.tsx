import React, {
  createContext,
  PropsWithChildren,
  useCallback,
  useContext,
  useEffect,
  useState,
} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  useSendChatMessage,
  useGenerateImage,
  type ChatMessage,
} from '@workspace/api-client-react';

const CHAT_STORAGE_KEY = 'turbo-ai/chat-history';
const GALLERY_STORAGE_KEY = 'turbo-ai/gallery';
const MAX_STORED_IMAGES = 12;

function makeId(): string {
  return Date.now().toString() + Math.random().toString(36).slice(2, 9);
}

// ---------------------------------------------------------------------------
// Chat
// ---------------------------------------------------------------------------

export interface DisplayChatMessage extends ChatMessage {
  id: string;
}

interface ChatContextValue {
  messages: DisplayChatMessage[];
  isSending: boolean;
  errorMessage: string | null;
  isLoaded: boolean;
  sendMessage: (text: string) => Promise<void>;
  clearChat: () => void;
  dismissError: () => void;
}

const ChatContext = createContext<ChatContextValue | null>(null);

function ChatProvider({ children }: PropsWithChildren) {
  const [messages, setMessages] = useState<DisplayChatMessage[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const sendChatMessage = useSendChatMessage();

  useEffect(() => {
    (async () => {
      try {
        const stored = await AsyncStorage.getItem(CHAT_STORAGE_KEY);
        if (stored) {
          setMessages(JSON.parse(stored) as DisplayChatMessage[]);
        }
      } catch {
        // Ignore corrupt/missing storage — start with an empty conversation.
      } finally {
        setIsLoaded(true);
      }
    })();
  }, []);

  const persist = useCallback((next: DisplayChatMessage[]) => {
    AsyncStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(next)).catch(() => {
      // Persistence failures should not break the chat experience.
    });
  }, []);

  const sendMessage = useCallback(
    async (text: string) => {
      const trimmed = text.trim();
      if (!trimmed) return;

      setErrorMessage(null);

      const userMessage: DisplayChatMessage = {
        id: makeId(),
        role: 'user',
        content: trimmed,
      };

      setMessages((prev) => {
        const next = [...prev, userMessage];
        persist(next);
        return next;
      });

      try {
        const conversation = [...messages, userMessage].map(
          ({ role, content }) => ({ role, content }),
        );
        const reply = await sendChatMessage.mutateAsync({
          data: { messages: conversation },
        });

        setMessages((prev) => {
          const next: DisplayChatMessage[] = [
            ...prev,
            { id: makeId(), ...reply.message },
          ];
          persist(next);
          return next;
        });
      } catch (err) {
        const message =
          err instanceof Error
            ? err.message
            : 'Turbo AI could not respond right now.';
        setErrorMessage(message);
      }
    },
    [messages, persist, sendChatMessage],
  );

  const clearChat = useCallback(() => {
    setMessages([]);
    setErrorMessage(null);
    AsyncStorage.removeItem(CHAT_STORAGE_KEY).catch(() => {});
  }, []);

  const dismissError = useCallback(() => setErrorMessage(null), []);

  return (
    <ChatContext.Provider
      value={{
        messages,
        isSending: sendChatMessage.isPending,
        errorMessage,
        isLoaded,
        sendMessage,
        clearChat,
        dismissError,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
}

export function useChat(): ChatContextValue {
  const ctx = useContext(ChatContext);
  if (!ctx) throw new Error('useChat must be used within a TurboProvider');
  return ctx;
}

// ---------------------------------------------------------------------------
// Image gallery
// ---------------------------------------------------------------------------

export interface GeneratedImage {
  id: string;
  prompt: string;
  base64: string;
  createdAt: number;
}

interface GalleryContextValue {
  images: GeneratedImage[];
  isGenerating: boolean;
  errorMessage: string | null;
  isLoaded: boolean;
  generate: (prompt: string) => Promise<void>;
  clearGallery: () => void;
  dismissError: () => void;
}

const GalleryContext = createContext<GalleryContextValue | null>(null);

function GalleryProvider({ children }: PropsWithChildren) {
  const [images, setImages] = useState<GeneratedImage[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const generateImageMutation = useGenerateImage();

  useEffect(() => {
    (async () => {
      try {
        const stored = await AsyncStorage.getItem(GALLERY_STORAGE_KEY);
        if (stored) {
          setImages(JSON.parse(stored) as GeneratedImage[]);
        }
      } catch {
        // Ignore corrupt/missing storage — start with an empty gallery.
      } finally {
        setIsLoaded(true);
      }
    })();
  }, []);

  const persist = useCallback((next: GeneratedImage[]) => {
    AsyncStorage.setItem(GALLERY_STORAGE_KEY, JSON.stringify(next)).catch(
      () => {},
    );
  }, []);

  const generate = useCallback(
    async (prompt: string) => {
      const trimmed = prompt.trim();
      if (!trimmed) return;

      setErrorMessage(null);

      try {
        const result = await generateImageMutation.mutateAsync({
          data: { prompt: trimmed, size: '1024x1024' },
        });

        setImages((prev) => {
          const next = [
            {
              id: makeId(),
              prompt: trimmed,
              base64: result.b64Json,
              createdAt: Date.now(),
            },
            ...prev,
          ].slice(0, MAX_STORED_IMAGES);
          persist(next);
          return next;
        });
      } catch (err) {
        const message =
          err instanceof Error
            ? err.message
            : 'Turbo AI could not generate that image right now.';
        setErrorMessage(message);
      }
    },
    [generateImageMutation, persist],
  );

  const clearGallery = useCallback(() => {
    setImages([]);
    setErrorMessage(null);
    AsyncStorage.removeItem(GALLERY_STORAGE_KEY).catch(() => {});
  }, []);

  const dismissError = useCallback(() => setErrorMessage(null), []);

  return (
    <GalleryContext.Provider
      value={{
        images,
        isGenerating: generateImageMutation.isPending,
        errorMessage,
        isLoaded,
        generate,
        clearGallery,
        dismissError,
      }}
    >
      {children}
    </GalleryContext.Provider>
  );
}

export function useGallery(): GalleryContextValue {
  const ctx = useContext(GalleryContext);
  if (!ctx) throw new Error('useGallery must be used within a TurboProvider');
  return ctx;
}

// ---------------------------------------------------------------------------
// Combined provider
// ---------------------------------------------------------------------------

export function TurboProvider({ children }: PropsWithChildren) {
  return (
    <ChatProvider>
      <GalleryProvider>{children}</GalleryProvider>
    </ChatProvider>
  );
}
