import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import type { DisplayChatMessage } from '@/context/TurboContext';

export function ChatBubble({ message }: { message: DisplayChatMessage }) {
  const colors = useColors();
  const isUser = message.role === 'user';

  return (
    <View
      style={[
        styles.row,
        { justifyContent: isUser ? 'flex-end' : 'flex-start' },
      ]}
    >
      <View
        style={[
          styles.bubble,
          {
            backgroundColor: isUser
              ? colors.bubbleUser
              : colors.bubbleAssistant,
            borderBottomRightRadius: isUser ? 6 : colors.radius,
            borderBottomLeftRadius: isUser ? colors.radius : 6,
          },
        ]}
      >
        <Text
          style={[
            styles.text,
            { color: isUser ? colors.bubbleUserText : colors.bubbleAssistantText },
          ]}
        >
          {message.content}
        </Text>
      </View>
    </View>
  );
}

export function TypingBubble() {
  const colors = useColors();
  return (
    <View style={[styles.row, { justifyContent: 'flex-start' }]}>
      <View
        style={[
          styles.bubble,
          styles.typingBubble,
          {
            backgroundColor: colors.bubbleAssistant,
            borderBottomLeftRadius: 6,
          },
        ]}
      >
        <View style={styles.dotsRow}>
          <View style={[styles.dot, { backgroundColor: colors.mutedForeground }]} />
          <View style={[styles.dot, { backgroundColor: colors.mutedForeground }]} />
          <View style={[styles.dot, { backgroundColor: colors.mutedForeground }]} />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    marginVertical: 4,
  },
  bubble: {
    maxWidth: '82%',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 20,
  },
  text: {
    fontSize: 16,
    lineHeight: 22,
    fontFamily: 'Inter_400Regular',
  },
  typingBubble: {
    paddingVertical: 16,
  },
  dotsRow: {
    flexDirection: 'row',
    gap: 4,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    opacity: 0.6,
  },
});
