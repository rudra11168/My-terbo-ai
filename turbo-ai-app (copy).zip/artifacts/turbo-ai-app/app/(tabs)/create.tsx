import React, { useCallback, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Image,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useColors } from '@/hooks/useColors';
import { useGallery, type GeneratedImage } from '@/context/TurboContext';
import { EmptyState } from '@/components/EmptyState';

export default function CreateScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    images,
    isGenerating,
    errorMessage,
    generate,
    clearGallery,
    dismissError,
  } = useGallery();
  const [prompt, setPrompt] = useState('');

  const canGenerate = prompt.trim().length > 0 && !isGenerating;

  const handleGenerate = useCallback(() => {
    if (!canGenerate) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    const text = prompt;
    setPrompt('');
    generate(text);
  }, [canGenerate, generate, prompt]);

  const renderItem = useCallback(
    ({ item }: { item: GeneratedImage }) => (
      <View
        style={[
          styles.card,
          { backgroundColor: colors.card, borderColor: colors.border },
        ]}
      >
        <Image
          source={{ uri: `data:image/png;base64,${item.base64}` }}
          style={styles.image}
          resizeMode="cover"
        />
        <Text
          style={[styles.caption, { color: colors.mutedForeground }]}
          numberOfLines={2}
        >
          {item.prompt}
        </Text>
      </View>
    ),
    [colors],
  );

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.background }}
      behavior="padding"
      keyboardVerticalOffset={0}
    >
      <View
        style={[
          styles.header,
          { paddingTop: insets.top + 12, borderBottomColor: colors.border },
        ]}
      >
        <View>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>
            Create
          </Text>
          <Text style={[styles.headerSubtitle, { color: colors.mutedForeground }]}>
            Turn words into images
          </Text>
        </View>
        {images.length > 0 && (
          <Pressable
            onPress={clearGallery}
            hitSlop={12}
            style={({ pressed }) => [
              styles.iconButton,
              { backgroundColor: colors.secondary, opacity: pressed ? 0.6 : 1 },
            ]}
          >
            <Feather name="trash-2" size={18} color={colors.secondaryForeground} />
          </Pressable>
        )}
      </View>

      {images.length === 0 && !isGenerating ? (
        <EmptyState
          icon="image"
          title="Generate your first image"
          subtitle="Describe anything you can imagine and Turbo AI will bring it to life."
        />
      ) : (
        <FlatList
          data={images}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          numColumns={2}
          columnWrapperStyle={styles.columnWrapper}
          contentContainerStyle={styles.listContent}
          keyboardShouldPersistTaps="handled"
          ListHeaderComponent={
            isGenerating ? (
              <View
                style={[
                  styles.generatingCard,
                  { backgroundColor: colors.card, borderColor: colors.border },
                ]}
              >
                <ActivityIndicator color={colors.primary} />
                <Text style={[styles.generatingText, { color: colors.mutedForeground }]}>
                  Creating your image…
                </Text>
              </View>
            ) : null
          }
        />
      )}

      {errorMessage && (
        <Pressable
          onPress={dismissError}
          style={[styles.errorBanner, { backgroundColor: colors.destructive }]}
        >
          <Text style={styles.errorText} numberOfLines={2}>
            {errorMessage}
          </Text>
        </Pressable>
      )}

      <View
        style={[
          styles.inputRow,
          {
            paddingBottom: Math.max(insets.bottom, 12),
            borderTopColor: colors.border,
            backgroundColor: colors.background,
          },
        ]}
      >
        <TextInput
          value={prompt}
          onChangeText={setPrompt}
          placeholder="Describe an image"
          placeholderTextColor={colors.mutedForeground}
          multiline
          style={[
            styles.input,
            {
              backgroundColor: colors.card,
              color: colors.foreground,
              borderColor: colors.border,
            },
          ]}
        />
        <Pressable
          onPress={handleGenerate}
          disabled={!canGenerate}
          style={({ pressed }) => [
            styles.sendButton,
            {
              backgroundColor: canGenerate ? colors.accent : colors.muted,
              opacity: pressed ? 0.8 : 1,
            },
          ]}
        >
          <Feather
            name="zap"
            size={20}
            color={canGenerate ? colors.accentForeground : colors.mutedForeground}
          />
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  headerTitle: {
    fontSize: 22,
    fontFamily: 'Inter_700Bold',
  },
  headerSubtitle: {
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    marginTop: 2,
  },
  iconButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  listContent: {
    padding: 12,
    gap: 12,
  },
  columnWrapper: {
    gap: 12,
  },
  card: {
    flex: 1,
    borderRadius: 16,
    borderWidth: StyleSheet.hairlineWidth,
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    aspectRatio: 1,
  },
  caption: {
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
    padding: 8,
  },
  generatingCard: {
    width: '100%',
    borderRadius: 16,
    borderWidth: StyleSheet.hairlineWidth,
    paddingVertical: 24,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginBottom: 12,
  },
  generatingText: {
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
  },
  errorBanner: {
    marginHorizontal: 16,
    marginBottom: 8,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  errorText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
    paddingHorizontal: 16,
    paddingTop: 10,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  input: {
    flex: 1,
    maxHeight: 120,
    minHeight: 44,
    borderRadius: 22,
    borderWidth: StyleSheet.hairlineWidth,
    paddingHorizontal: 16,
    paddingVertical: 11,
    fontSize: 16,
    fontFamily: 'Inter_400Regular',
  },
  sendButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
